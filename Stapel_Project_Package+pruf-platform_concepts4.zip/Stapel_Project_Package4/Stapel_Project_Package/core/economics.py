"""Юнит-экономика СТАПЕЛЯ.

Главный тезис: тяжёлая часть продукта (рекомендации, защиты, валидатор)
детерминированная и стоит 0 ₽ за вызов. Языковая модель нужна только
для подсказок-подталкиваний, поэтому себестоимость студента измеряется рублями.
Цены на токены взяты по публичному тарифу отечественной модели уровня Lite.
"""

from __future__ import annotations

from typing import Any, Dict, List

PRICING = {
    "student": 0,                        # студент не платит никогда
    "university_per_student_year": 190,  # лицензия вуза за студента в год
    "department_flow_year": 35000,       # отдельная кафедра/поток до 200 студентов
    "college_year": 25000,               # колледж СПО
}

COSTS = {
    "hint_tokens": 1800,          # средний размер одной подсказки с контекстом
    "hints_per_year": 24,         # 12 подсказок за семестр
    "llm_price_per_1k": 0.065,    # ₽ за 1000 токенов, модель уровня Lite
    "infra_per_student_year": 34, # хранение, прогоны тестов, резервные копии
    "support_per_student_year": 25,
    "fixed_year": 480000,         # поддержка и развитие после гранта
}


def tutor_cost_per_student_year() -> float:
    tokens = COSTS["hint_tokens"] * COSTS["hints_per_year"]
    return round(tokens / 1000.0 * COSTS["llm_price_per_1k"], 2)


def unit_economics() -> Dict[str, Any]:
    tutor = tutor_cost_per_student_year()
    variable = round(tutor + COSTS["infra_per_student_year"] + COSTS["support_per_student_year"], 2)
    price = PRICING["university_per_student_year"]
    return {
        "price_per_student_year": price,
        "tutor_tokens_year": COSTS["hint_tokens"] * COSTS["hints_per_year"],
        "tutor_cost_year": tutor,
        "infra_cost_year": COSTS["infra_per_student_year"],
        "support_cost_year": COSTS["support_per_student_year"],
        "deterministic_cost_year": 0.0,
        "variable_cost_year": variable,
        "gross_margin_rub": round(price - variable, 2),
        "gross_margin_share": round((price - variable) / price, 3),
        "breakeven_students": int(-(-COSTS["fixed_year"] // (price - variable))),
    }


SCENARIOS: List[Dict[str, Any]] = [
    {"period": "Пилот, 1 семестр", "universities": 1, "departments": 1, "students": 150, "paid": False},
    {"period": "Год 1", "universities": 1, "departments": 4, "students": 600, "paid": True},
    {"period": "Год 2", "universities": 3, "departments": 14, "students": 4000, "paid": True},
    {"period": "Год 3", "universities": 12, "departments": 55, "students": 20000, "paid": True},
]


def scenario_table() -> List[Dict[str, Any]]:
    unit = unit_economics()
    rows = []
    for scenario in SCENARIOS:
        students = scenario["students"]
        revenue = students * PRICING["university_per_student_year"] if scenario["paid"] else 0
        variable = round(students * unit["variable_cost_year"])
        rows.append({
            "period": scenario["period"],
            "universities": scenario["universities"],
            "departments": scenario["departments"],
            "students": students,
            "revenue": revenue,
            "variable_cost": variable,
            "contribution": revenue - variable,
            "result": revenue - variable - (COSTS["fixed_year"] if scenario["paid"] else 0),
        })
    return rows


def cost_comparison() -> Dict[str, Any]:
    """Стоимость проверки понимания: мутации против опроса языковой модели."""
    defenses_per_student_year = 60
    llm_tokens_per_defense = 2600
    llm_cost = round(defenses_per_student_year * llm_tokens_per_defense / 1000.0
                     * COSTS["llm_price_per_1k"], 2)
    return {
        "defenses_per_student_year": defenses_per_student_year,
        "stapel_cost": 0.0,
        "llm_based_cost": llm_cost,
        "llm_tokens": defenses_per_student_year * llm_tokens_per_defense,
        "comment": "Защиты СТАПЕЛЯ считаются запуском тестов, а не вызовом модели",
    }


GRANT_BUDGET = [
    {"item": "Разработка ядра и конструктора (4 чел., 6 мес.)", "sum": 720000},
    {"item": "Песочница запуска кода и сервер в контуре вуза", "sum": 180000},
    {"item": "Контент первых двух курсов с кафедрой", "sum": 150000},
    {"item": "Пилот на потоке и замер результатов", "sum": 90000},
    {"item": "Оформление РИД и регистрация программы", "sum": 60000},
]


def grant_total() -> int:
    return sum(row["sum"] for row in GRANT_BUDGET)


def report() -> Dict[str, Any]:
    return {
        "pricing": PRICING,
        "unit": unit_economics(),
        "scenarios": scenario_table(),
        "defense_cost": cost_comparison(),
        "grant": {"items": GRANT_BUDGET, "total": grant_total()},
    }


if __name__ == "__main__":
    import json

    print(json.dumps(report(), ensure_ascii=False, indent=1))
