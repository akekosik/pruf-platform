"""Демонстрационные данные СТАПЕЛЯ: курс кафедры, студенты, код и тесты.

Все цифры здесь — учебные, но структура совпадает с боевой:
так же выглядит курс, собранный преподавателем в конструкторе.
"""

from __future__ import annotations

from typing import Any, Dict, List

# ---------------------------------------------------------------------
# Рабочая программа дисциплины (из которой берутся индикаторы)
# ---------------------------------------------------------------------

RPD: Dict[str, Any] = {
    "discipline": "Программирование и основы алгоритмизации",
    "program": "27.03.04 Управление в технических системах",
    "semester": "1 курс, 2 семестр",
    "indicators": [
        {"code": "ОПК-2.1", "text": "Применяет базовые конструкции языка программирования"},
        {"code": "ОПК-2.2", "text": "Разрабатывает и тестирует функции с заданным контрактом"},
        {"code": "ОПК-7.1", "text": "Обрабатывает данные и штатные ошибки при работе с файлами"},
        {"code": "ПК-1.3", "text": "Проектирует и реализует программный интерфейс сервиса"},
    ],
}

# ---------------------------------------------------------------------
# Граф навыков
# ---------------------------------------------------------------------

SKILLS: Dict[str, Dict[str, Any]] = {
    "s_var":  {"title": "Переменные и типы", "prereq": []},
    "s_cond": {"title": "Условия и границы", "prereq": ["s_var"]},
    "s_loop": {"title": "Циклы", "prereq": ["s_var"]},
    "s_list": {"title": "Списки и срезы", "prereq": ["s_loop"]},
    "s_dict": {"title": "Словари", "prereq": ["s_list"]},
    "s_func": {"title": "Функции и контракты", "prereq": ["s_cond", "s_loop"]},
    "s_test": {"title": "Тесты и граничные случаи", "prereq": ["s_func"]},
    "s_file": {"title": "Файлы и JSON", "prereq": ["s_dict", "s_func"]},
    "s_err":  {"title": "Ошибки и исключения", "prereq": ["s_func"]},
    "s_cli":  {"title": "Командная строка", "prereq": ["s_file"]},
    "s_http": {"title": "HTTP и маршруты", "prereq": ["s_dict", "s_err"]},
    "s_api":  {"title": "Проектирование API", "prereq": ["s_http", "s_test"]},
}

MODULES: List[Dict[str, Any]] = [
    {"id": "m1", "title": "Ядро расчётов", "artifact": "чистые функции с тестами"},
    {"id": "m2", "title": "Хранилище задач", "artifact": "сохранение и чтение JSON"},
    {"id": "m3", "title": "Командная строка", "artifact": "рабочая утилита add / list / done"},
    {"id": "m4", "title": "Веб-API", "artifact": "HTTP-сервис задач"},
    {"id": "m5", "title": "Релиз и защита", "artifact": "собранный проект v1.0"},
]


def _step(sid, title, module, skills, difficulty, minutes, kind, autocheck, defense,
          why="", indicators=None, misconceptions=None) -> Dict[str, Any]:
    return {
        "id": sid, "title": title, "module": module, "skills": list(skills),
        "difficulty": float(difficulty), "minutes": int(minutes), "kind": kind,
        "autocheck": bool(autocheck), "defense": int(defense), "why": why,
        "indicators": list(indicators or []), "misconceptions": list(misconceptions or []),
    }


# Черновик курса такой, каким его собирает преподаватель в первый раз: с типовыми ошибками.
STEPS_DRAFT: List[Dict[str, Any]] = [
    _step("t01", "Переменная и вывод результата", "m1", ["s_var"], 900, 6, "practice", True, 0,
          "Чтобы хранить исходные данные задачи.", ["ОПК-2.1"]),
    _step("t02", "Условие и его граница", "m1", ["s_cond"], 950, 8, "practice", True, 2,
          "Граница условия — самое частое место ошибок.", ["ОПК-2.1"], ["boundary"]),
    _step("t03", "Цикл: сумма и счётчик", "m1", ["s_loop"], 990, 9, "practice", True, 0,
          "Без цикла не собрать статистику по задачам.", ["ОПК-2.1"], ["off_by_one"]),
    _step("t04", "Функция с контрактом", "m1", ["s_func"], 1040, 10, "practice", True, 2,
          "Функция — первая деталь проекта, которую можно проверить.", ["ОПК-2.2"]),
    _step("t05", "Сборка: калькулятор нагрузки", "m1", ["s_func", "s_cond"], 1080, 12, "assembly", True, 2,
          "Первый модуль проекта готов и работает.", ["ОПК-2.2"]),

    _step("t06", "Списки и срезы", "m2", ["s_list"], 1120, 8, "practice", True, 0,
          "", ["ОПК-2.1"], ["off_by_one"]),
    _step("t07", "Словарь как хранилище", "m2", ["s_dict"], 1150, 9, "practice", True, 2,
          "Задача проекта — это запись со свойствами.", ["ОПК-2.1"]),
    _step("t08", "Тесты на границы", "m2", ["s_test"], 1190, 10, "practice", True, 2,
          "Тест ловит ошибку раньше преподавателя.", ["ОПК-2.2"], ["boundary"]),
    _step("t09", "Файл JSON: чтение и запись", "m2", ["s_file"], 1230, 18, "practice", True, 0,
          "Чтобы задачи не терялись между запусками.", ["ОПК-7.1"]),
    _step("t10", "Сборка: хранилище задач", "m2", ["s_file", "s_dict"], 1270, 12, "assembly", True, 2,
          "Второй модуль проекта готов.", ["ОПК-7.1"]),

    _step("t11", "Ошибки вместо падений", "m3", ["s_err"], 1310, 9, "practice", True, 2,
          "Пользователь должен видеть понятное сообщение, а не трассировку.", ["ОПК-7.1"]),
    _step("t12", "Как устроена командная строка", "m3", ["s_cli"], 1330, 7, "theory", False, 0,
          "Чтобы понимать, откуда берутся аргументы запуска.", ["ОПК-7.1"]),
    _step("t13", "Аргументы командной строки", "m3", ["s_cli"], 1360, 10, "practice", False, 0,
          "", ["ОПК-7.1"]),
    _step("t14", "Сборка: команды add / list / done", "m3", ["s_cli", "s_err"], 1400, 12, "assembly", True, 2,
          "Третий модуль: проектом уже можно пользоваться.", ["ОПК-7.1"]),

    _step("t15", "HTTP за шесть минут", "m4", ["s_http"], 1420, 6, "theory", False, 0,
          "Чтобы понимать, что такое запрос и ответ.", []),
    _step("t16", "Маршрут и ответ сервиса", "m4", ["s_http"], 1750, 10, "practice", True, 2,
          "Первый живой маршрут твоего сервиса.", []),
    _step("t17", "Коды ответов и ошибки", "m4", ["s_http", "s_err", "s_test"], 1490, 10, "practice", True, 0,
          "Сервис обязан честно сообщать об ошибках.", ["ОПК-7.1"]),
    _step("t18", "Проектирование ресурсов API", "m4", ["s_api"], 1530, 11, "practice", True, 2,
          "Сначала договор, потом код.", []),
    _step("t19", "Сборка: API задач", "m4", ["s_api", "s_http"], 1570, 12, "assembly", True, 2,
          "Четвёртый модуль: сервис отвечает по сети.", []),

    _step("t20", "Тесты для API", "m5", ["s_test", "s_api"], 1610, 11, "practice", True, 0,
          "", ["ОПК-2.2"]),
    _step("t21", "Упаковка и запуск", "m5", ["s_file"], 1640, 10, "practice", True, 0,
          "Чтобы проект запускался не только на твоём компьютере.", ["ОПК-7.1"]),
    _step("t22", "Сборка: релиз v1.0 и защита", "m5", ["s_api"], 1680, 12, "assembly", True, 3,
          "Спуск на воду: проект готов к защите.", ["ОПК-2.2"]),
]

COURSE_DRAFT: Dict[str, Any] = {
    "id": "sevsu-python-service-2026",
    "title": "Python и веб-сервис: от переменной до работающего API",
    "author": "кафедра «Искусственный интеллект и автономные системы управления»",
    "final_project": "Сервис учёта задач с HTTP-интерфейсом и тестами",
    "modules": MODULES,
    "skills": SKILLS,
    "steps": STEPS_DRAFT,
}

# ---------------------------------------------------------------------
# Состояние студента на 14-й день семестра
# ---------------------------------------------------------------------

NOW_DAY = 14.0

STUDENT_STATE: Dict[str, Any] = {
    "id": "stu-ohrimenko",
    "name": "Охрименко А.",
    "group": "УТС/б-25-1-о",
    "rating": 1180.0,
    "current_module": "m2",
    "mastery": {
        "s_var": 0.96, "s_cond": 0.91, "s_loop": 0.78, "s_func": 0.86,
        "s_list": 0.62, "s_dict": 0.41, "s_test": 0.28, "s_file": 0.18,
        "s_err": 0.15, "s_cli": 0.15, "s_http": 0.15, "s_api": 0.15,
    },
    "memory": {
        "s_var": {"reviews": 4, "lapses": 0, "last_day": 5.0},
        "s_cond": {"reviews": 3, "lapses": 0, "last_day": 7.0},
        "s_loop": {"reviews": 3, "lapses": 1, "last_day": 9.0},
        "s_func": {"reviews": 2, "lapses": 0, "last_day": 11.0},
        "s_list": {"reviews": 1, "lapses": 0, "last_day": 12.0},
    },
    "completed": {
        "t01": {"day": 2.0, "correct": True, "defended": True},
        "t02": {"day": 3.0, "correct": True, "defended": True},
        "t03": {"day": 5.0, "correct": False, "defended": False},
        "t04": {"day": 8.0, "correct": True, "defended": True},
        "t05": {"day": 11.0, "correct": True, "defended": True},
        "t06": {"day": 12.0, "correct": True, "defended": True},
    },
    "recent_skills": ["s_list", "s_list"],
    "misconceptions": {"off_by_one": 2, "boundary": 0},
}

# ---------------------------------------------------------------------
# Код студента и тесты шага — из них строится защита
# ---------------------------------------------------------------------

STUDENT_CODE = '''def normalize(scores):
    """Обрезает баллы до диапазона 0..100 и переводит в доли."""
    result = []
    for score in scores:
        if score < 0:
            score = 0
        if score > 100:
            score = 100
        result.append(round(score / 100, 2))
    return result


def top_scores(scores, limit=3):
    """Возвращает лучшие баллы по убыванию."""
    ranked = sorted(scores, reverse=True)
    return ranked[:limit]
'''

STEP_TESTS: List[Dict[str, Any]] = [
    {"name": "тест 1: обычные баллы", "call": "normalize([50, 100])", "expected": [0.5, 1.0]},
    {"name": "тест 2: отрицательный балл", "call": "normalize([-5, 20])", "expected": [0.0, 0.2]},
    {"name": "тест 3: балл выше сотни", "call": "normalize([120])", "expected": [1.0]},
    {"name": "тест 4: три лучших по умолчанию", "call": "top_scores([1, 2, 3, 4])", "expected": [4, 3, 2]},
    {"name": "тест 5: лучшие два", "call": "top_scores([1, 5, 3, 9], 2)", "expected": [9, 5]},
]

# ---------------------------------------------------------------------
# Лига недели и события начисления
# ---------------------------------------------------------------------

LEAGUE_STUDENTS: List[Dict[str, Any]] = [
    {"id": "s01", "name": "Охрименко А.", "group": "УТС/б-25-1-о", "points": 268, "rating": 1180},
    {"id": "s02", "name": "Коваленко Д.", "group": "УТС/б-25-1-о", "points": 305, "rating": 1240},
    {"id": "s03", "name": "Мартынова Е.", "group": "УТС/б-25-2-о", "points": 291, "rating": 1090},
    {"id": "s04", "name": "Савицкий Р.", "group": "УТС/б-25-1-о", "points": 254, "rating": 1310},
    {"id": "s05", "name": "Гуреев М.", "group": "УТС/б-25-2-о", "points": 232, "rating": 1005},
    {"id": "s06", "name": "Иванченко Л.", "group": "УТС/б-25-2-о", "points": 210, "rating": 1150},
    {"id": "s07", "name": "Петросян А.", "group": "УТС/б-25-1-о", "points": 188, "rating": 1420},
    {"id": "s08", "name": "Шевченко К.", "group": "УТС/б-25-2-о", "points": 174, "rating": 980},
    {"id": "s09", "name": "Дорошенко В.", "group": "УТС/б-25-1-о", "points": 156, "rating": 1075},
    {"id": "s10", "name": "Абрамов С.", "group": "УТС/б-25-2-о", "points": 120, "rating": 1260},
    {"id": "s11", "name": "Зайцева Н.", "group": "УТС/б-25-1-о", "points": 96, "rating": 1020},
    {"id": "s12", "name": "Воронов И.", "group": "УТС/б-25-2-о", "points": 0, "rating": 950},
]

POINT_EVENTS: List[Dict[str, Any]] = [
    {"student": "s01", "day": 1, "skill": "s_list", "predicted": 0.74, "defended": True},
    {"student": "s01", "day": 1, "skill": "s_list", "predicted": 0.71, "defended": True},
    {"student": "s01", "day": 1, "skill": "s_list", "predicted": 0.69, "defended": True},
    {"student": "s01", "day": 1, "skill": "s_list", "predicted": 0.68, "defended": True},   # 4-й повтор — ноль
    {"student": "s01", "day": 1, "skill": "s_dict", "predicted": 0.97, "defended": True},   # слишком легко
    {"student": "s01", "day": 2, "skill": "s_dict", "predicted": 0.66, "defended": False},  # без защиты
    {"student": "s01", "day": 2, "skill": "s_func", "predicted": 0.58, "defended": True},
    {"student": "s02", "day": 1, "skill": "s_test", "predicted": 0.60, "defended": True},
    {"student": "s02", "day": 2, "skill": "s_file", "predicted": 0.62, "defended": True},
]

DUEL_LEFT = {"id": "s01", "defended": 3, "minutes": 21.5}
DUEL_RIGHT = {"id": "s03", "defended": 3, "minutes": 24.0}


def course_draft() -> Dict[str, Any]:
    """Свежая копия черновика курса (чтобы тесты не мешали друг другу)."""
    import copy

    return copy.deepcopy(COURSE_DRAFT)


def student_state() -> Dict[str, Any]:
    import copy

    return copy.deepcopy(STUDENT_STATE)
