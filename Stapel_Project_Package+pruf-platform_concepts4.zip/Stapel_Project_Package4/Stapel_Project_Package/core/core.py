"""
СТАПЕЛЬ — эталонное ядро платформы микрообучения.

Здесь собрано всё, что в продукте считается «по-честному»:
  * модель знаний студента (BKT) и рейтинг сложности (Elo);
  * интервальные повторения (кривая забывания);
  * объяснимый подбор следующего шага;
  * генерация вопросов-защит из кода самого студента (мутационное тестирование);
  * зачёт соревнования по приросту и антифарм-правила;
  * валидатор курса преподавателя и покрытие индикаторов компетенций.

Свойства файла:
  * ноль внешних зависимостей и ноль обращений к сети или к языковой модели;
  * детерминированность: одинаковый вход — одинаковый выход;
  * та же логика повторена в браузерном прототипе (parity-проверки в test_core.py).
"""

from __future__ import annotations

import ast
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple

SCHEMA_VERSION = "stapel.core/1"

# =====================================================================
# 1. Модель знаний студента: Bayesian Knowledge Tracing
# =====================================================================

DEFAULT_BKT: Dict[str, float] = {
    "p_init": 0.15,     # вероятность, что навык уже освоен до начала курса
    "p_transit": 0.18,  # вероятность освоить навык на очередной попытке
    "p_slip": 0.10,     # знал, но ошибся
    "p_guess": 0.20,    # не знал, но угадал
}

MASTERY_UNLOCK = 0.75   # порог открытия следующих навыков
MASTERY_DONE = 0.90     # порог «навык освоен»


def bkt_update(p_known: float, correct: bool, params: Optional[Dict[str, float]] = None) -> float:
    """Обновляет вероятность владения навыком после одной попытки."""
    p = dict(DEFAULT_BKT)
    if params:
        p.update(params)
    p_known = min(max(float(p_known), 0.0), 1.0)
    if correct:
        num = p_known * (1.0 - p["p_slip"])
        den = num + (1.0 - p_known) * p["p_guess"]
    else:
        num = p_known * p["p_slip"]
        den = num + (1.0 - p_known) * (1.0 - p["p_guess"])
    posterior = (num / den) if den > 0 else p_known
    updated = posterior + (1.0 - posterior) * p["p_transit"]
    return round(min(max(updated, 0.0), 0.999), 6)


def mastery_label(p_known: float) -> str:
    """Человеческая подпись к числу мастерства."""
    if p_known >= MASTERY_DONE:
        return "освоен"
    if p_known >= MASTERY_UNLOCK:
        return "почти освоен"
    if p_known >= 0.4:
        return "в работе"
    return "начало"


# =====================================================================
# 2. Сложность заданий: рейтинг Elo
# =====================================================================

ELO_K_STUDENT = 32.0
ELO_K_ITEM = 8.0
TARGET_SUCCESS = 0.78     # целевая вероятность успеха (зона ближайшего развития)
SUCCESS_BAND = (0.55, 0.90)  # полоса, в которой шаг вообще имеет смысл


def success_probability(student_rating: float, item_difficulty: float) -> float:
    """Вероятность того, что студент справится с заданием такой сложности."""
    return round(1.0 / (1.0 + 10.0 ** ((item_difficulty - student_rating) / 400.0)), 6)


def elo_update(
    student_rating: float,
    item_difficulty: float,
    correct: bool,
    k_student: float = ELO_K_STUDENT,
    k_item: float = ELO_K_ITEM,
) -> Tuple[float, float]:
    """Обновляет рейтинг студента и сложность шага после попытки."""
    expected = success_probability(student_rating, item_difficulty)
    outcome = 1.0 if correct else 0.0
    return (
        round(student_rating + k_student * (outcome - expected), 2),
        round(item_difficulty + k_item * (expected - outcome), 2),
    )


# =====================================================================
# 3. Интервальные повторения: кривая забывания
# =====================================================================

BASE_HALF_LIFE_DAYS = 1.0
HALF_LIFE_GROWTH = 2.0
HALF_LIFE_LAPSE_PENALTY = 1.6
MAX_HALF_LIFE_DAYS = 120.0
REVIEW_THRESHOLD = 0.70


def half_life_days(successful_reviews: int, lapses: int = 0) -> float:
    """Период полураспада памяти по навыку в сутках."""
    reviews = max(0, int(successful_reviews))
    misses = max(0, int(lapses))
    h = BASE_HALF_LIFE_DAYS * (HALF_LIFE_GROWTH ** reviews) / (HALF_LIFE_LAPSE_PENALTY ** misses)
    return round(min(max(h, 0.25), MAX_HALF_LIFE_DAYS), 4)


def recall_probability(half_life: float, days_elapsed: float) -> float:
    """Вероятность вспомнить навык через days_elapsed суток."""
    days = max(0.0, float(days_elapsed))
    h = max(0.0001, float(half_life))
    return round(2.0 ** (-days / h), 6)


def needs_review(half_life: float, days_elapsed: float, threshold: float = REVIEW_THRESHOLD) -> bool:
    return recall_probability(half_life, days_elapsed) < threshold


def skill_recall(state: Dict[str, Any], skill_id: str, now_day: float) -> float:
    """Текущее удержание навыка у студента (1.0, если навык ещё не встречался)."""
    memory = state.get("memory", {}).get(skill_id)
    if not memory:
        return 1.0
    h = half_life_days(memory.get("reviews", 0), memory.get("lapses", 0))
    return recall_probability(h, max(0.0, now_day - memory.get("last_day", now_day)))


# =====================================================================
# 4. Граф навыков
# =====================================================================


def topological_order(skills: Dict[str, Dict[str, Any]]) -> List[str]:
    """Порядок изучения навыков. При цикле в графе бросает ValueError."""
    pending = {sid: list(data.get("prereq", [])) for sid, data in skills.items()}
    order: List[str] = []
    while pending:
        ready = sorted(sid for sid, prereq in pending.items() if not [p for p in prereq if p in pending])
        if not ready:
            raise ValueError("в графе навыков есть цикл: " + ", ".join(sorted(pending)))
        for sid in ready:
            order.append(sid)
            pending.pop(sid)
    return order


def skill_unlocked(skills: Dict[str, Dict[str, Any]], mastery: Dict[str, float], skill_id: str,
                   threshold: float = MASTERY_UNLOCK) -> bool:
    """Навык открыт, если все его предшественники доведены до порога."""
    for prereq in skills.get(skill_id, {}).get("prereq", []):
        if mastery.get(prereq, 0.0) < threshold:
            return False
    return True


def missing_prerequisites(skills: Dict[str, Dict[str, Any]], mastery: Dict[str, float],
                          skill_id: str, threshold: float = MASTERY_UNLOCK) -> List[str]:
    return [p for p in skills.get(skill_id, {}).get("prereq", []) if mastery.get(p, 0.0) < threshold]


# =====================================================================
# 5. Рекомендательный движок: какой шаг дать следующим
# =====================================================================

WEIGHTS = {
    "fit": 0.34,        # сложность в зоне ближайшего развития
    "review": 0.24,     # пора повторить забываемый навык
    "project": 0.22,    # шаг собирает текущий модуль проекта
    "repair": 0.12,     # шаг чинит замеченную ошибку понимания
    "variety": 0.08,    # смена темы, чтобы не буксовать
}
FIT_SIGMA = 0.13


@dataclass
class Recommendation:
    step_id: str
    title: str
    score: float
    predicted_success: float
    minutes: int
    factors: Dict[str, float]
    reasons: List[str]
    kind: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "title": self.title,
            "score": self.score,
            "predicted_success": self.predicted_success,
            "minutes": self.minutes,
            "factors": self.factors,
            "reasons": self.reasons,
            "kind": self.kind,
        }


def _fit_score(predicted: float) -> float:
    return round(math.exp(-((predicted - TARGET_SUCCESS) ** 2) / (2.0 * FIT_SIGMA ** 2)), 6)


def _module_distance(course: Dict[str, Any], step_module: str, current_module: str) -> int:
    ids = [m["id"] for m in course.get("modules", [])]
    if step_module not in ids or current_module not in ids:
        return 9
    return ids.index(step_module) - ids.index(current_module)


def predict_step_success(course: Dict[str, Any], state: Dict[str, Any], step: Dict[str, Any]) -> float:
    """Прогноз успеха: рейтинг Elo плюс мастерство по навыкам шага."""
    elo_part = success_probability(state.get("rating", 1000.0), step.get("difficulty", 1000.0))
    skills = step.get("skills") or []
    if skills:
        mastery = sum(state.get("mastery", {}).get(s, DEFAULT_BKT["p_init"]) for s in skills) / len(skills)
    else:
        mastery = 0.5
    return round(0.6 * elo_part + 0.4 * mastery, 6)


def recommend(course: Dict[str, Any], state: Dict[str, Any], now_day: float, limit: int = 3
              ) -> List[Recommendation]:
    """Ранжирует доступные шаги и объясняет, почему именно эти."""
    skills = course.get("skills", {})
    mastery = state.get("mastery", {})
    completed = state.get("completed", {})
    recent = list(state.get("recent_skills", []))[-2:]
    misconceptions = {tag for tag, count in state.get("misconceptions", {}).items() if count > 0}
    current_module = state.get("current_module", (course.get("modules") or [{"id": ""}])[0]["id"])

    result: List[Recommendation] = []
    for step in course.get("steps", []):
        step_skills = step.get("skills") or []
        blocked = [p for s in step_skills for p in missing_prerequisites(skills, mastery, s)]
        if blocked:
            continue

        recalls = {s: skill_recall(state, s, now_day) for s in step_skills}
        weakest_recall = min(recalls.values()) if recalls else 1.0
        review_gap = max(0.0, (REVIEW_THRESHOLD - weakest_recall) / REVIEW_THRESHOLD)

        done = step["id"] in completed
        if done and review_gap <= 0:
            continue
        if done and step.get("kind") == "theory":
            continue

        predicted = predict_step_success(course, state, step)
        fit = _fit_score(predicted)
        distance = _module_distance(course, step.get("module", ""), current_module)
        project = 1.0 if distance == 0 else (0.5 if distance == 1 else 0.12)
        repair = 1.0 if misconceptions & set(step.get("misconceptions") or []) else 0.0
        variety = 0.0 if any(s in recent for s in step_skills) else 1.0

        factors = {
            "fit": fit,
            "review": round(review_gap, 6),
            "project": project,
            "repair": repair,
            "variety": variety,
        }
        score = round(sum(WEIGHTS[k] * v for k, v in factors.items()), 6)

        reasons: List[str] = []
        ordered = sorted(factors.items(), key=lambda kv: WEIGHTS[kv[0]] * kv[1], reverse=True)
        for name, value in ordered:
            if value <= 0:
                continue
            if name == "fit":
                reasons.append(f"сложность подобрана под тебя: шанс справиться {round(predicted * 100)} %")
            elif name == "review":
                weak = min(recalls, key=lambda s: recalls[s])
                title = skills.get(weak, {}).get("title", weak)
                reasons.append(
                    f"навык «{title}» пора повторить: удержание упало до {round(recalls[weak] * 100)} %")
            elif name == "project" and distance == 0:
                module_title = next((m["title"] for m in course.get("modules", [])
                                     if m["id"] == step.get("module")), step.get("module", ""))
                reasons.append(f"шаг собирает модуль «{module_title}» твоего проекта")
            elif name == "repair":
                reasons.append("чинит именно ту ошибку, которую ты повторил в последних попытках")
            elif name == "variety":
                reasons.append("смена темы после двух шагов подряд на одном навыке")
        result.append(Recommendation(
            step_id=step["id"],
            title=step.get("title", step["id"]),
            score=score,
            predicted_success=predicted,
            minutes=int(step.get("minutes", 10)),
            factors=factors,
            reasons=reasons[:2],
            kind=step.get("kind", "practice"),
        ))

    result.sort(key=lambda r: (-r.score, r.step_id))
    return result[:limit]


def locked_steps(course: Dict[str, Any], state: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Шаги, закрытые пререквизитами, с указанием причины."""
    skills = course.get("skills", {})
    mastery = state.get("mastery", {})
    out: List[Dict[str, Any]] = []
    for step in course.get("steps", []):
        blocked = sorted({p for s in (step.get("skills") or [])
                          for p in missing_prerequisites(skills, mastery, s)})
        if blocked:
            out.append({
                "step_id": step["id"],
                "title": step.get("title", step["id"]),
                "blocked_by": [skills.get(b, {}).get("title", b) for b in blocked],
            })
    return out


# =====================================================================
# 6. Защита понимания: вопросы из кода самого студента
# =====================================================================
#
# Идея: мы не спрашиваем «что такое цикл» — это гуглится и спрашивается у модели.
# Мы берём ИМЕННО тот код, который студент только что сдал, вносим в него одну
# точечную правку (мутацию) и спрашиваем, что сломается. Ответ проверяется запуском
# тестов, а не моделью. На такой вопрос нельзя ответить, не понимая свой код.

SAFE_BUILTINS: Dict[str, Any] = {
    "abs": abs, "all": all, "any": any, "bool": bool, "dict": dict, "divmod": divmod,
    "enumerate": enumerate, "float": float, "int": int, "len": len, "list": list,
    "max": max, "min": min, "range": range, "reversed": reversed, "round": round,
    "set": set, "sorted": sorted, "str": str, "sum": sum, "tuple": tuple, "zip": zip,
    "ValueError": ValueError, "TypeError": TypeError, "IndexError": IndexError,
    "KeyError": KeyError, "ZeroDivisionError": ZeroDivisionError, "Exception": Exception,
}

_CMP_SWAP = {ast.Lt: ast.LtE, ast.LtE: ast.Lt, ast.Gt: ast.GtE, ast.GtE: ast.Gt,
             ast.Eq: ast.NotEq, ast.NotEq: ast.Eq}
_BIN_SWAP = {ast.Add: ast.Sub, ast.Sub: ast.Add, ast.Mult: ast.Add}
_SYMBOL = {ast.Lt: "<", ast.LtE: "<=", ast.Gt: ">", ast.GtE: ">=", ast.Eq: "==",
           ast.NotEq: "!=", ast.Add: "+", ast.Sub: "-", ast.Mult: "*"}


@dataclass
class Mutant:
    id: str
    line: int
    kind: str
    before: str
    after: str
    code: str

    def as_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "line": self.line, "kind": self.kind,
                "before": self.before, "after": self.after}


def run_tests(code: str, tests: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Запускает набор тестов над кодом в ограниченном окружении."""
    namespace: Dict[str, Any] = {"__builtins__": dict(SAFE_BUILTINS)}
    try:
        exec(compile(code, "<student>", "exec"), namespace)  # noqa: S102 - контролируемое окружение
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}",
                "passed": [], "failed": [t["name"] for t in tests]}
    passed: List[str] = []
    failed: List[str] = []
    for test in tests:
        try:
            got = eval(test["call"], namespace)  # noqa: S307 - контролируемое окружение
            (passed if got == test["expected"] else failed).append(test["name"])
        except Exception:  # noqa: BLE001
            failed.append(test["name"])
    return {"ok": not failed, "error": None, "passed": passed, "failed": failed}


def _mutation_sites(tree: ast.AST) -> List[Dict[str, Any]]:
    sites: List[Dict[str, Any]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            for index, op in enumerate(node.ops):
                op_type = type(op)
                if op_type in _CMP_SWAP:
                    sites.append({"kind": "сравнение", "line": getattr(node, "lineno", 0),
                                  "col": getattr(node, "col_offset", 0),
                                  "before": _SYMBOL[op_type], "after": _SYMBOL[_CMP_SWAP[op_type]],
                                  "node": node, "index": index, "what": "cmp"})
        elif isinstance(node, ast.BinOp):
            op_type = type(node.op)
            if op_type in _BIN_SWAP:
                sites.append({"kind": "арифметика", "line": getattr(node, "lineno", 0),
                              "col": getattr(node, "col_offset", 0),
                              "before": _SYMBOL[op_type], "after": _SYMBOL[_BIN_SWAP[op_type]],
                              "node": node, "index": 0, "what": "bin"})
        elif isinstance(node, ast.Constant) and isinstance(node.value, int) and not isinstance(node.value, bool):
            sites.append({"kind": "число", "line": getattr(node, "lineno", 0),
                          "col": getattr(node, "col_offset", 0),
                          "before": str(node.value), "after": str(node.value + 1),
                          "node": node, "index": 0, "what": "const"})
    sites.sort(key=lambda s: (s["line"], s["col"], s["what"], s["before"]))
    return sites


def generate_mutants(code: str, limit: int = 12) -> List[Mutant]:
    """Строит точечные правки кода: одна мутация — одно изменение."""
    total = len(_mutation_sites(ast.parse(code)))
    mutants: List[Mutant] = []
    for position in range(min(total, limit)):
        tree = ast.parse(code)
        site = _mutation_sites(tree)[position]
        node = site["node"]
        if site["what"] == "cmp":
            node.ops[site["index"]] = _CMP_SWAP[type(node.ops[site["index"]])]()
        elif site["what"] == "bin":
            node.op = _BIN_SWAP[type(node.op)]()
        else:
            node.value = node.value + 1
        ast.fix_missing_locations(tree)
        mutants.append(Mutant(id=f"M{position + 1:02d}", line=site["line"], kind=site["kind"],
                              before=site["before"], after=site["after"], code=ast.unparse(tree)))
    return mutants


NO_TEST_OPTION = "ни один тест не заметит правку"
DEFENSE_PASS_RATIO = 2.0 / 3.0


def build_defense(code: str, tests: Sequence[Dict[str, Any]], limit: int = 3,
                  include_survivor: bool = True) -> Dict[str, Any]:
    """Собирает вопросы защиты по конкретному коду студента."""
    baseline = run_tests(code, tests)
    if not baseline["ok"]:
        raise ValueError("защита собирается только по коду, который уже проходит все тесты")

    killed: List[Tuple[Mutant, Dict[str, Any]]] = []
    survived: List[Tuple[Mutant, Dict[str, Any]]] = []
    for mutant in generate_mutants(code):
        result = run_tests(mutant.code, tests)
        (killed if result["failed"] else survived).append((mutant, result))

    options = [t["name"] for t in tests] + [NO_TEST_OPTION]
    questions: List[Dict[str, Any]] = []
    for mutant, result in killed[:limit]:
        first_failed = next(t["name"] for t in tests if t["name"] in result["failed"])
        questions.append({
            "id": f"Q{len(questions) + 1}",
            "mutant_id": mutant.id,
            "line": mutant.line,
            "text": (f"Строка {mutant.line}: если заменить «{mutant.before}» на «{mutant.after}», "
                     f"какой тест упадёт первым?"),
            "options": options,
            "answer": first_failed,
            "kind": mutant.kind,
            "hint": "Подумай, какой случай проверяет границу именно этого условия.",
        })
    if include_survivor and survived:
        mutant, _ = survived[0]
        questions.append({
            "id": f"Q{len(questions) + 1}",
            "mutant_id": mutant.id,
            "line": mutant.line,
            "text": (f"Строка {mutant.line}: если заменить «{mutant.before}» на «{mutant.after}», "
                     f"какой тест упадёт первым?"),
            "options": options,
            "answer": NO_TEST_OPTION,
            "kind": mutant.kind,
            "hint": "Здесь ловушка: в твоём наборе тестов есть дыра — этот случай никто не проверяет.",
            "gap": True,
        })
    return {
        "schema": SCHEMA_VERSION,
        "mutants_total": len(killed) + len(survived),
        "killed": len(killed),
        "survived": len(survived),
        "mutation_score": round(len(killed) / max(1, len(killed) + len(survived)), 4),
        "questions": questions,
    }


def grade_defense(defense: Dict[str, Any], answers: Dict[str, str]) -> Dict[str, Any]:
    """Проверяет ответы на защите. Без защиты шаг не засчитывается."""
    questions = defense.get("questions", [])
    detail = []
    correct = 0
    for question in questions:
        given = answers.get(question["id"])
        ok = given == question["answer"]
        correct += 1 if ok else 0
        detail.append({"id": question["id"], "correct": ok, "given": given, "expected": question["answer"]})
    total = len(questions)
    ratio = (correct / total) if total else 0.0
    return {
        "total": total,
        "correct": correct,
        "ratio": round(ratio, 4),
        "passed": total > 0 and ratio >= DEFENSE_PASS_RATIO,
        "detail": detail,
    }


# =====================================================================
# 7. Соревнование: лиги по приросту, команды, дуэли
# =====================================================================

POINTS_BASE = 10
DAILY_POINT_CAP = 120
REPEAT_LIMIT_PER_SKILL = 3
PROMOTION_SLOTS = 5
RELEGATION_SLOTS = 5
LEAGUES = ["Киль", "Шпангоут", "Обшивка", "Палуба", "Рубка", "Капитанская"]


def step_points(predicted_success: float, defended: bool, repeat_index: int = 0) -> int:
    """Очки за шаг. Три антифарм-правила вшиты прямо сюда."""
    if not defended:
        return 0                                     # 1. без защиты очков нет
    if not (SUCCESS_BAND[0] <= predicted_success <= SUCCESS_BAND[1]):
        return 0                                     # 2. слишком лёгкое или непосильное не считается
    if repeat_index >= REPEAT_LIMIT_PER_SKILL:
        return 0                                     # 3. нельзя фармить один навык бесконечно
    challenge = 1.0 - predicted_success
    return int(round(POINTS_BASE * (1.0 + 2.0 * challenge)))


def award_week(events: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Начисляет очки за неделю с учётом суточного потолка и повторов."""
    per_day: Dict[Tuple[str, int], int] = {}
    repeats: Dict[Tuple[str, int, str], int] = {}
    totals: Dict[str, int] = {}
    rejected: List[Dict[str, Any]] = []
    for event in events:
        student = event["student"]
        day = int(event.get("day", 0))
        skill = event.get("skill", "")
        key = (student, day, skill)
        repeat_index = repeats.get(key, 0)
        repeats[key] = repeat_index + 1
        points = step_points(float(event.get("predicted", 0.5)), bool(event.get("defended")), repeat_index)
        if points == 0:
            rejected.append({"student": student, "day": day, "skill": skill,
                             "reason": ("нет защиты" if not event.get("defended")
                                        else "повтор навыка" if repeat_index >= REPEAT_LIMIT_PER_SKILL
                                        else "вне полосы сложности")})
            continue
        spent = per_day.get((student, day), 0)
        allowed = max(0, DAILY_POINT_CAP - spent)
        granted = min(points, allowed)
        if granted < points:
            rejected.append({"student": student, "day": day, "skill": skill, "reason": "суточный потолок"})
        per_day[(student, day)] = spent + granted
        totals[student] = totals.get(student, 0) + granted
    return {"points": totals, "rejected": rejected}


def league_table(students: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Недельная таблица лиги: места по приросту, а не по абсолютному уровню."""
    rows = [dict(s) for s in students]
    rows.sort(key=lambda r: (-int(r.get("points", 0)), r.get("id", "")))
    size = len(rows)
    for index, row in enumerate(rows):
        row["place"] = index + 1
        if index < PROMOTION_SLOTS:
            row["zone"] = "повышение"
        elif index >= size - RELEGATION_SLOTS:
            row["zone"] = "понижение"
        else:
            row["zone"] = "остаётся"
    return rows


def team_scores(students: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Командный зачёт учебных групп: средний прирост на человека."""
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for student in students:
        groups.setdefault(student.get("group", "без группы"), []).append(student)
    rows = []
    for name, members in groups.items():
        points = sum(int(m.get("points", 0)) for m in members)
        active = sum(1 for m in members if int(m.get("points", 0)) > 0)
        rows.append({
            "group": name,
            "members": len(members),
            "active": active,
            "points": points,
            "per_member": round(points / max(1, len(members)), 1),
            "participation": round(active / max(1, len(members)), 3),
        })
    rows.sort(key=lambda r: (-r["per_member"], r["group"]))
    for index, row in enumerate(rows):
        row["place"] = index + 1
    return rows


def duel_result(left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
    """Дуэль на одинаковом наборе шагов: сначала защиты, потом время."""
    def key(side: Dict[str, Any]) -> Tuple[int, float]:
        return (-int(side.get("defended", 0)), float(side.get("minutes", 10 ** 6)))
    if key(left) == key(right):
        return {"winner": None, "draw": True, "left": left, "right": right}
    winner = left if key(left) < key(right) else right
    return {"winner": winner.get("id"), "draw": False, "left": left, "right": right}


# =====================================================================
# 8. Валидатор курса преподавателя
# =====================================================================

MAX_STEP_MINUTES = 12
MAX_DIFFICULTY_JUMP = 250.0
MAX_NEW_SKILLS_PER_STEP = 2
MAX_THEORY_SHARE = 0.40

RULE_TITLES = {
    "C01": "Шаг длиннее 12 минут",
    "C02": "У шага нет автопроверки",
    "C03": "Пререквизит не объявлен в графе навыков",
    "C04": "В графе навыков есть цикл",
    "C05": "Модуль проекта без шага сборки",
    "C06": "Слишком большой скачок сложности",
    "C07": "Навык не закрыт ни одной защитой",
    "C08": "Индикатор компетенции не покрыт ни одним шагом",
    "C09": "В одном шаге больше двух новых навыков",
    "C10": "Не заполнено поле «зачем этот шаг»",
    "C11": "Шаг не привязан к модулю проекта",
    "C12": "В модуле слишком много теории",
}
AUTOFIXABLE = {"C06", "C07", "C10"}


def _violation(code: str, location: str, found: Any, expected: Any, severity: str) -> Dict[str, Any]:
    return {
        "code": code,
        "message": RULE_TITLES[code],
        "severity": severity,
        "location": location,
        "found": found,
        "expected": expected,
        "autofixable": code in AUTOFIXABLE,
    }


def validate_course(course: Dict[str, Any], rpd: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Проверяет курс перед публикацией. Все правила детерминированны."""
    steps = course.get("steps", [])
    skills = course.get("skills", {})
    modules = course.get("modules", [])
    violations: List[Dict[str, Any]] = []

    for step in steps:
        title = step.get("title", step["id"])
        if int(step.get("minutes", 0)) > MAX_STEP_MINUTES:
            violations.append(_violation("C01", title, f"{step.get('minutes')} мин",
                                         f"не больше {MAX_STEP_MINUTES} мин", "minor"))
        if step.get("kind") in {"practice", "assembly"} and not step.get("autocheck"):
            violations.append(_violation("C02", title, "ручная проверка", "тесты или проверка артефакта", "major"))
        if len(step.get("skills") or []) > MAX_NEW_SKILLS_PER_STEP:
            violations.append(_violation("C09", title, f"{len(step.get('skills'))} навыка",
                                         f"не больше {MAX_NEW_SKILLS_PER_STEP}", "minor"))
        if not (step.get("why") or "").strip():
            violations.append(_violation("C10", title, "пусто", "одна фраза для студента", "minor"))
        if step.get("module") not in {m["id"] for m in modules}:
            violations.append(_violation("C11", title, step.get("module") or "нет",
                                         "модуль итогового проекта", "major"))

    for skill_id, data in sorted(skills.items()):
        for prereq in data.get("prereq", []):
            if prereq not in skills:
                violations.append(_violation("C03", data.get("title", skill_id), prereq,
                                             "навык из графа курса", "critical"))
    try:
        topological_order(skills)
    except ValueError as exc:
        violations.append(_violation("C04", "граф навыков", str(exc), "граф без циклов", "critical"))

    for module in modules:
        module_steps = [s for s in steps if s.get("module") == module["id"]]
        if not any(s.get("kind") == "assembly" for s in module_steps):
            violations.append(_violation("C05", module.get("title", module["id"]), "нет шага сборки",
                                         "один шаг типа «сборка»", "major"))
        total_minutes = sum(int(s.get("minutes", 0)) for s in module_steps)
        theory_minutes = sum(int(s.get("minutes", 0)) for s in module_steps if s.get("kind") == "theory")
        if total_minutes and theory_minutes / total_minutes > MAX_THEORY_SHARE:
            violations.append(_violation("C12", module.get("title", module["id"]),
                                         f"{round(100 * theory_minutes / total_minutes)} % теории",
                                         f"не больше {round(MAX_THEORY_SHARE * 100)} %", "minor"))

    for previous, current in zip(steps, steps[1:]):
        jump = float(current.get("difficulty", 0)) - float(previous.get("difficulty", 0))
        if jump > MAX_DIFFICULTY_JUMP:
            violations.append(_violation("C06", current.get("title", current["id"]),
                                         f"+{round(jump)} пунктов",
                                         f"не больше +{round(MAX_DIFFICULTY_JUMP)}", "major"))

    defended_skills = {s for step in steps if int(step.get("defense", 0)) > 0 for s in (step.get("skills") or [])}
    for skill_id, data in sorted(skills.items()):
        if skill_id not in defended_skills:
            violations.append(_violation("C07", data.get("title", skill_id), "только автотесты",
                                         "хотя бы одна защита", "major"))

    if rpd:
        covered = {code for step in steps for code in (step.get("indicators") or [])}
        for indicator in rpd.get("indicators", []):
            if indicator["code"] not in covered:
                violations.append(_violation("C08", indicator["code"], "нет шагов",
                                             "хотя бы один шаг с этим индикатором", "critical"))

    severity_order = {"critical": 0, "major": 1, "minor": 2}
    violations.sort(key=lambda v: (severity_order[v["severity"]], v["code"], str(v["location"])))
    by_severity = {level: sum(1 for v in violations if v["severity"] == level)
                   for level in ("critical", "major", "minor")}
    return {
        "schema": SCHEMA_VERSION,
        "course_id": course.get("id"),
        "violations": violations,
        "total": len(violations),
        "by_severity": by_severity,
        "autofixable": sum(1 for v in violations if v["autofixable"]),
        "ready_to_publish": by_severity["critical"] == 0 and by_severity["major"] == 0,
    }


def autofix_course(course: Dict[str, Any], rpd: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Чинит механические замечания (C06, C07, C10) и возвращает новый курс."""
    import copy

    fixed = copy.deepcopy(course)
    steps = fixed.get("steps", [])
    skills = fixed.get("skills", {})
    applied: List[str] = []

    for step in steps:
        if not (step.get("why") or "").strip():
            names = [skills.get(s, {}).get("title", s) for s in (step.get("skills") or [])]
            step["why"] = ("Шаг даёт навык: " + ", ".join(names)) if names else "Шаг двигает проект вперёд."
            applied.append("C10")

    for previous, current in zip(steps, steps[1:]):
        jump = float(current.get("difficulty", 0)) - float(previous.get("difficulty", 0))
        if jump > MAX_DIFFICULTY_JUMP:
            current["difficulty"] = round(float(previous.get("difficulty", 0)) + MAX_DIFFICULTY_JUMP - 50.0, 2)
            applied.append("C06")

    defended_skills = {s for step in steps if int(step.get("defense", 0)) > 0 for s in (step.get("skills") or [])}
    for skill_id in sorted(skills):
        if skill_id in defended_skills:
            continue
        candidates = [s for s in steps if skill_id in (s.get("skills") or [])
                      and s.get("kind") in {"practice", "assembly"}]
        if candidates:
            candidates[-1]["defense"] = max(2, int(candidates[-1].get("defense", 0)))
            applied.append("C07")

    return {"course": fixed, "applied": applied, "report": validate_course(fixed, rpd)}


# =====================================================================
# 9. Компетенции и сборка проекта
# =====================================================================


def competency_coverage(course: Dict[str, Any], rpd: Dict[str, Any]) -> Dict[str, Any]:
    """Отчёт кафедре: какие индикаторы РПД закрыты шагами и защитами."""
    rows = []
    for indicator in rpd.get("indicators", []):
        linked = [s for s in course.get("steps", []) if indicator["code"] in (s.get("indicators") or [])]
        rows.append({
            "code": indicator["code"],
            "text": indicator.get("text", ""),
            "steps": len(linked),
            "minutes": sum(int(s.get("minutes", 0)) for s in linked),
            "defenses": sum(int(s.get("defense", 0)) for s in linked),
            "covered": bool(linked) and any(int(s.get("defense", 0)) > 0 for s in linked),
        })
    covered = sum(1 for r in rows if r["covered"])
    return {
        "discipline": rpd.get("discipline", ""),
        "indicators": rows,
        "covered": covered,
        "total": len(rows),
        "share": round(covered / max(1, len(rows)), 3),
    }


def module_progress(course: Dict[str, Any], state: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Состояние сборки проекта по модулям."""
    completed = state.get("completed", {})
    rows = []
    for module in course.get("modules", []):
        module_steps = [s for s in course.get("steps", []) if s.get("module") == module["id"]]
        done = [s for s in module_steps if s["id"] in completed]
        defended = [s for s in done if completed[s["id"]].get("defended")]
        total = len(module_steps)
        rows.append({
            "id": module["id"],
            "title": module.get("title", module["id"]),
            "artifact": module.get("artifact", ""),
            "steps_total": total,
            "steps_done": len(done),
            "defended": len(defended),
            "percent": round(100 * len(done) / max(1, total)),
            "status": ("собран" if total and len(defended) == total
                       else "в сборке" if done else "не начат"),
        })
    return rows


def launch_readiness(course: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]:
    """Готовность к «спуску на воду»: все модули собраны и защищены."""
    rows = module_progress(course, state)
    blocking = [r["title"] for r in rows if r["status"] != "собран"]
    total_steps = sum(r["steps_total"] for r in rows)
    done_steps = sum(r["steps_done"] for r in rows)
    return {
        "modules": rows,
        "ready": not blocking,
        "blocking": blocking,
        "percent": round(100 * done_steps / max(1, total_steps)),
        "verdict": ("Проект готов к защите" if not blocking
                    else "Осталось собрать: " + ", ".join(blocking)),
    }


__all__ = [
    "SCHEMA_VERSION", "DEFAULT_BKT", "bkt_update", "mastery_label", "success_probability",
    "elo_update", "half_life_days", "recall_probability", "needs_review", "skill_recall",
    "topological_order", "skill_unlocked", "missing_prerequisites", "recommend", "locked_steps",
    "predict_step_success", "Recommendation", "run_tests", "generate_mutants", "build_defense",
    "grade_defense", "step_points", "award_week", "league_table", "team_scores", "duel_result",
    "validate_course", "autofix_course", "competency_coverage", "module_progress", "launch_readiness",
]
