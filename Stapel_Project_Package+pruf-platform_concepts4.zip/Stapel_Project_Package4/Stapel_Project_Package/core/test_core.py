"""Тесты ядра СТАПЕЛЯ. Запуск: python3 test_core.py

Без внешних библиотек: простой раннер по функциям test_*.
"""

from __future__ import annotations

import sys
import traceback

sys.path.insert(0, "/data/stapel/reference")

import core
import fixtures as fx


# ---------- 1. Модель знаний ----------

def test_bkt_correct_increases():
    assert core.bkt_update(0.30, True) > 0.30


def test_bkt_wrong_pulls_down():
    after_wrong = core.bkt_update(0.60, False)
    after_right = core.bkt_update(0.60, True)
    assert after_wrong < after_right
    assert after_wrong < 0.60


def test_bkt_stays_in_range():
    value = 0.05
    for _ in range(40):
        value = core.bkt_update(value, True)
    assert 0.0 <= value <= 0.999


def test_mastery_labels():
    assert core.mastery_label(0.95) == "освоен"
    assert core.mastery_label(0.80) == "почти освоен"
    assert core.mastery_label(0.10) == "начало"


# ---------- 2. Elo ----------

def test_success_probability_equal_is_half():
    assert core.success_probability(1200, 1200) == 0.5


def test_success_probability_monotonic():
    assert core.success_probability(1400, 1200) > core.success_probability(1000, 1200)


def test_elo_update_directions():
    up_student, down_item = core.elo_update(1200, 1300, True)
    assert up_student > 1200 and down_item < 1300
    down_student, up_item = core.elo_update(1200, 1300, False)
    assert down_student < 1200 and up_item > 1300


# ---------- 3. Память ----------

def test_half_life_doubles():
    assert core.half_life_days(3) == 2 * core.half_life_days(2)


def test_lapses_shorten_memory():
    assert core.half_life_days(3, 1) < core.half_life_days(3, 0)


def test_recall_decays_and_flags_review():
    fresh = core.recall_probability(5.0, 0.0)
    old = core.recall_probability(5.0, 10.0)
    assert fresh == 1.0 and old < 0.3
    assert core.needs_review(5.0, 10.0) is True
    assert core.needs_review(30.0, 1.0) is False


# ---------- 4. Граф навыков ----------

def test_topological_order_respects_prereq():
    order = core.topological_order(fx.SKILLS)
    assert len(order) == len(fx.SKILLS)
    assert order.index("s_var") < order.index("s_loop") < order.index("s_list")
    assert order.index("s_http") < order.index("s_api")


def test_cycle_is_rejected():
    broken = {"a": {"prereq": ["b"]}, "b": {"prereq": ["a"]}}
    try:
        core.topological_order(broken)
    except ValueError:
        return
    raise AssertionError("цикл в графе должен был вызвать ошибку")


def test_missing_prerequisites_listed():
    state = fx.student_state()
    assert core.missing_prerequisites(fx.SKILLS, state["mastery"], "s_dict") == ["s_list"]
    assert core.missing_prerequisites(fx.SKILLS, state["mastery"], "s_cond") == []


# ---------- 5. Рекомендации ----------

def test_recommend_returns_sorted_limited():
    recs = core.recommend(fx.course_draft(), fx.student_state(), fx.NOW_DAY, limit=3)
    assert len(recs) == 3
    assert recs[0].score >= recs[1].score >= recs[2].score


def test_recommend_top_step_is_repair_of_loops():
    recs = core.recommend(fx.course_draft(), fx.student_state(), fx.NOW_DAY, limit=3)
    assert recs[0].step_id == "t03"
    assert recs[0].reasons, "рекомендация обязана объясняться"
    assert all(isinstance(reason, str) and reason for reason in recs[0].reasons)


def test_recommend_never_offers_locked_steps():
    recs = core.recommend(fx.course_draft(), fx.student_state(), fx.NOW_DAY, limit=10)
    offered = {r.step_id for r in recs}
    locked = {row["step_id"] for row in core.locked_steps(fx.course_draft(), fx.student_state())}
    assert not (offered & locked)


def test_locked_steps_name_the_blocker():
    locked = core.locked_steps(fx.course_draft(), fx.student_state())
    by_id = {row["step_id"]: row for row in locked}
    assert "t07" in by_id
    assert by_id["t07"]["blocked_by"] == ["Списки и срезы"]


def test_predicted_success_within_unit_interval():
    course = fx.course_draft()
    state = fx.student_state()
    for step in course["steps"]:
        value = core.predict_step_success(course, state, step)
        assert 0.0 <= value <= 1.0


# ---------- 6. Защита понимания ----------

def test_reference_code_passes_tests():
    result = core.run_tests(fx.STUDENT_CODE, fx.STEP_TESTS)
    assert result["ok"] is True
    assert result["failed"] == []


def test_broken_code_fails_tests():
    broken = fx.STUDENT_CODE.replace("score > 100", "score > 1000")
    result = core.run_tests(broken, fx.STEP_TESTS)
    assert result["ok"] is False
    assert "тест 3: балл выше сотни" in result["failed"]


def test_mutants_are_deterministic_and_different():
    first = core.generate_mutants(fx.STUDENT_CODE)
    second = core.generate_mutants(fx.STUDENT_CODE)
    assert [m.as_dict() for m in first] == [m.as_dict() for m in second]
    assert len(first) == 9
    for mutant in first:
        assert mutant.code != fx.STUDENT_CODE


def test_defense_is_built_from_student_code():
    defense = core.build_defense(fx.STUDENT_CODE, fx.STEP_TESTS, limit=3)
    assert defense["mutants_total"] == 9
    assert defense["killed"] == 4
    assert defense["survived"] == 5
    assert len(defense["questions"]) == 4
    assert defense["questions"][-1]["answer"] == core.NO_TEST_OPTION
    assert defense["questions"][-1].get("gap") is True
    for question in defense["questions"][:3]:
        assert question["answer"] in [t["name"] for t in fx.STEP_TESTS]


def test_defense_requires_working_code():
    broken = fx.STUDENT_CODE.replace("score > 100", "score > 1000")
    try:
        core.build_defense(broken, fx.STEP_TESTS)
    except ValueError:
        return
    raise AssertionError("защита не должна строиться по нерабочему коду")


def test_grade_defense_pass_and_fail():
    defense = core.build_defense(fx.STUDENT_CODE, fx.STEP_TESTS, limit=3)
    perfect = {q["id"]: q["answer"] for q in defense["questions"]}
    assert core.grade_defense(defense, perfect)["passed"] is True
    weak = {q["id"]: "неверный ответ" for q in defense["questions"]}
    weak[defense["questions"][0]["id"]] = defense["questions"][0]["answer"]
    graded = core.grade_defense(defense, weak)
    assert graded["passed"] is False
    assert graded["correct"] == 1


# ---------- 7. Соревнование ----------

def test_points_require_defense_and_right_difficulty():
    assert core.step_points(0.70, False) == 0
    assert core.step_points(0.97, True) == 0
    assert core.step_points(0.30, True) == 0
    assert core.step_points(0.70, True) > 0


def test_harder_step_is_worth_more():
    assert core.step_points(0.60, True) > core.step_points(0.88, True)


def test_award_week_applies_anticheat():
    result = core.award_week(fx.POINT_EVENTS)
    assert result["points"]["s01"] == 65
    assert result["points"]["s02"] == 36
    reasons = sorted({row["reason"] for row in result["rejected"]})
    assert reasons == ["вне полосы сложности", "нет защиты", "повтор навыка"]
    assert len(result["rejected"]) == 3


def test_daily_cap_is_enforced():
    events = [{"student": "x", "day": 1, "skill": f"s{i}", "predicted": 0.56, "defended": True}
              for i in range(20)]
    result = core.award_week(events)
    assert result["points"]["x"] == core.DAILY_POINT_CAP


def test_league_zones():
    table = core.league_table(fx.LEAGUE_STUDENTS)
    assert table[0]["id"] == "s02"
    assert table[0]["zone"] == "повышение"
    assert table[-1]["zone"] == "понижение"
    assert [row["place"] for row in table] == list(range(1, len(fx.LEAGUE_STUDENTS) + 1))


def test_team_scores_rank_by_average():
    teams = core.team_scores(fx.LEAGUE_STUDENTS)
    assert teams[0]["group"] == "УТС/б-25-1-о"
    assert teams[0]["per_member"] > teams[1]["per_member"]
    assert teams[0]["participation"] == 1.0


def test_duel_winner_by_time_when_defenses_equal():
    assert core.duel_result(fx.DUEL_LEFT, fx.DUEL_RIGHT)["winner"] == "s01"
    assert core.duel_result(fx.DUEL_LEFT, fx.DUEL_LEFT)["draw"] is True


# ---------- 8. Валидатор курса ----------

def test_validator_finds_planted_problems():
    report = core.validate_course(fx.course_draft(), fx.RPD)
    assert report["total"] == 11
    assert report["by_severity"] == {"critical": 1, "major": 5, "minor": 5}
    assert report["autofixable"] == 7
    assert report["ready_to_publish"] is False
    codes = sorted({v["code"] for v in report["violations"]})
    assert codes == ["C01", "C02", "C06", "C07", "C08", "C09", "C10"]


def test_autofix_clears_mechanical_problems():
    fixed = core.autofix_course(fx.course_draft(), fx.RPD)
    assert len(fixed["applied"]) == 7
    assert sorted(set(fixed["applied"])) == ["C06", "C07", "C10"]
    remaining = {v["code"] for v in fixed["report"]["violations"]}
    assert remaining == {"C01", "C02", "C08", "C09"}
    assert fixed["report"]["total"] == 4


def test_clean_course_is_publishable():
    fixed = core.autofix_course(fx.course_draft(), fx.RPD)["course"]
    for step in fixed["steps"]:
        step["minutes"] = min(int(step["minutes"]), core.MAX_STEP_MINUTES)
        step["skills"] = step["skills"][:core.MAX_NEW_SKILLS_PER_STEP]
        if step["kind"] in {"practice", "assembly"}:
            step["autocheck"] = True
        if step["id"] == "t18":
            step["indicators"] = list(set(step["indicators"] + ["ПК-1.3"]))
    report = core.validate_course(fixed, fx.RPD)
    assert report["total"] == 0
    assert report["ready_to_publish"] is True


# ---------- 9. Компетенции и проект ----------

def test_competency_coverage_reports_gap():
    coverage = core.competency_coverage(fx.course_draft(), fx.RPD)
    assert coverage["total"] == 4
    assert coverage["covered"] == 3
    assert coverage["share"] == 0.75
    uncovered = [row["code"] for row in coverage["indicators"] if not row["covered"]]
    assert uncovered == ["ПК-1.3"]


def test_module_progress_marks_undefended_module():
    rows = core.module_progress(fx.course_draft(), fx.student_state())
    first = rows[0]
    assert first["steps_total"] == 5
    assert first["steps_done"] == 5
    assert first["defended"] == 4
    assert first["status"] == "в сборке"


def test_launch_readiness_blocks_until_all_modules_done():
    readiness = core.launch_readiness(fx.course_draft(), fx.student_state())
    assert readiness["ready"] is False
    assert readiness["percent"] == 27
    assert "Веб-API" in readiness["blocking"]


def test_schema_version_is_pinned():
    assert core.SCHEMA_VERSION == "stapel.core/1"


def main() -> int:
    tests = sorted((name, obj) for name, obj in globals().items()
                   if name.startswith("test_") and callable(obj))
    failed = []
    for name, fn in tests:
        try:
            fn()
            print(f"  ok  {name}")
        except Exception:  # noqa: BLE001
            failed.append(name)
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\nИтого: {len(tests) - len(failed)}/{len(tests)} тестов пройдено")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
