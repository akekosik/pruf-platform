"""Собирает отчёты ядра и семя данных для браузерного прототипа.

Запуск: python3 demo.py
Результат: /data/stapel/reports/*.json и /data/stapel/prototype_seed.json
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, "/data/stapel/reference")

import core
import economics
import fixtures as fx

REPORTS = "/data/stapel/reports"
SEED = "/data/stapel/prototype_seed.json"


def write(path: str, payload) -> str:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=1)
    return path


def clean_course():
    """Курс после автопочинки и ручных правок преподавателя — именно он идёт студентам."""
    course = core.autofix_course(fx.course_draft(), fx.RPD)["course"]
    for step in course["steps"]:
        step["minutes"] = min(int(step["minutes"]), core.MAX_STEP_MINUTES)
        step["skills"] = step["skills"][: core.MAX_NEW_SKILLS_PER_STEP]
        if step["kind"] in {"practice", "assembly"}:
            step["autocheck"] = True
        if step["id"] in {"t16", "t18", "t19"} and "ПК-1.3" not in step["indicators"]:
            step["indicators"] = step["indicators"] + ["ПК-1.3"]
    return course


def main() -> int:
    draft = fx.course_draft()
    state = fx.student_state()
    course = clean_course()

    validation = core.validate_course(draft, fx.RPD)
    autofix = core.autofix_course(fx.course_draft(), fx.RPD)
    recommendations = [r.as_dict() for r in core.recommend(course, state, fx.NOW_DAY, limit=3)]
    defense = core.build_defense(fx.STUDENT_CODE, fx.STEP_TESTS, limit=3)
    mutants = []
    for mutant in core.generate_mutants(fx.STUDENT_CODE):
        outcome = core.run_tests(mutant.code, fx.STEP_TESTS)
        row = mutant.as_dict()
        row["killed"] = bool(outcome["failed"])
        row["failed_test"] = next((t["name"] for t in fx.STEP_TESTS
                                   if t["name"] in outcome["failed"]), None)
        mutants.append(row)
    league = core.league_table(fx.LEAGUE_STUDENTS)
    teams = core.team_scores(fx.LEAGUE_STUDENTS)
    award = core.award_week(fx.POINT_EVENTS)
    coverage_draft = core.competency_coverage(draft, fx.RPD)
    coverage_clean = core.competency_coverage(course, fx.RPD)
    readiness = core.launch_readiness(course, state)
    econ = economics.report()

    skill_rows = []
    for skill_id in core.topological_order(course["skills"]):
        data = course["skills"][skill_id]
        mastery = state["mastery"].get(skill_id, core.DEFAULT_BKT["p_init"])
        memory = state["memory"].get(skill_id)
        recall = core.skill_recall(state, skill_id, fx.NOW_DAY)
        skill_rows.append({
            "id": skill_id,
            "title": data["title"],
            "prereq": data.get("prereq", []),
            "mastery": round(mastery, 3),
            "label": core.mastery_label(mastery),
            "recall": recall,
            "half_life": core.half_life_days(memory["reviews"], memory["lapses"]) if memory else None,
            "needs_review": bool(memory) and recall < core.REVIEW_THRESHOLD,
            "unlocked": core.skill_unlocked(course["skills"], state["mastery"], skill_id),
        })

    files = [
        write(f"{REPORTS}/validation_draft.json", validation),
        write(f"{REPORTS}/validation_autofixed.json",
              {"applied": autofix["applied"], "report": autofix["report"]}),
        write(f"{REPORTS}/recommendations.json",
              {"now_day": fx.NOW_DAY, "student": state["name"], "items": recommendations}),
        write(f"{REPORTS}/defense.json", defense),
        write(f"{REPORTS}/league.json", {"table": league, "teams": teams, "award": award}),
        write(f"{REPORTS}/competency_coverage.json",
              {"draft": coverage_draft, "published": coverage_clean}),
        write(f"{REPORTS}/economics.json", econ),
        write(f"{REPORTS}/project_readiness.json", readiness),
    ]

    seed = {
        "schema": core.SCHEMA_VERSION,
        "generated_for": "stapel_prototype_full.html",
        "now_day": fx.NOW_DAY,
        "rpd": fx.RPD,
        "course": course,
        "course_draft": draft,
        "student": {
            "id": state["id"], "name": state["name"], "group": state["group"],
            "rating": state["rating"], "current_module": state["current_module"],
            "mastery": state["mastery"], "memory": state["memory"],
            "completed": state["completed"], "misconceptions": state["misconceptions"],
            "recent_skills": state["recent_skills"],
        },
        "skills_view": skill_rows,
        "recommendations": recommendations,
        "code": fx.STUDENT_CODE,
        "tests": fx.STEP_TESTS,
        "defense": defense,
        "mutants": mutants,
        "league": {"table": league, "teams": teams, "award": award,
                   "duel": core.duel_result(fx.DUEL_LEFT, fx.DUEL_RIGHT)},
        "validation": {"draft": validation, "autofix": {"applied": autofix["applied"],
                                                        "report": autofix["report"]}},
        "coverage": {"draft": coverage_draft, "published": coverage_clean},
        "readiness": readiness,
        "economics": econ,
        "constants": {
            "bkt": core.DEFAULT_BKT,
            "target_success": core.TARGET_SUCCESS,
            "success_band": list(core.SUCCESS_BAND),
            "weights": core.WEIGHTS,
            "review_threshold": core.REVIEW_THRESHOLD,
            "mastery_unlock": core.MASTERY_UNLOCK,
            "daily_cap": core.DAILY_POINT_CAP,
            "elo_k": [core.ELO_K_STUDENT, core.ELO_K_ITEM],
            "rule_titles": core.RULE_TITLES,
        },
    }
    write(SEED, seed)

    print("Отчёты:")
    for path in files:
        print("  ", path, os.path.getsize(path), "байт")
    print("Семя прототипа:", SEED, os.path.getsize(SEED), "байт")
    print("Проверка курса после правок:", core.validate_course(course, fx.RPD)["total"], "замечаний")
    print("Топ рекомендации:", [r["step_id"] for r in recommendations])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
